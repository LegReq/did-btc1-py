from setuptools import setup, find_packages

setup(
    name='libbtc1',
    version='0.1',
    description='A simple Python library for did:btc1',
    author='Will Abramson',
    packages=find_packages(),
)